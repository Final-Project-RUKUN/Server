'use strict';
const {
  Model
} = require('sequelize');
const { hashPassword } = require('../helpers/useBcrypt')
module.exports = (sequelize, DataTypes) => {
  class Users extends Model {
    
    static associate(models) {
      Users.hasMany(models.Suggestions)
      Users.hasMany(models.Transactions)
      Users.hasOne(models.Villages)
      console.log(models);
      Users.belongsTo(models.Villages)
    }
  };
  Users.init({
    name: {
      type: DataTypes.STRING,
      validate: {
        notEmpty: {
          args: true,
          msg: "Name is required"
        }
      }
    },
    username: {
      type: DataTypes.STRING,
      validate: {
        notEmpty: {
          args: true,
          msg: "Username is required"
        }
      }
    },
    password: {
      type: DataTypes.STRING,
      validate: {
        notEmpty: {
          args: true,
          msg: "Password is required"
        },
        passwordLength(value){
          if(value.length < 6) throw Error('More than six characters are required')
        }
      }
    },
    role: {
      type: DataTypes.STRING,
      validate: {
        notEmpty: {
          args: true,
          msg: "Role is required"
        }
      }
    },
    VillageId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Users',
    hooks: {
      beforeCreate(instance, option){
        instance.password = hashPassword(instance.password)
      }
    }
  });
  return Users;
};
